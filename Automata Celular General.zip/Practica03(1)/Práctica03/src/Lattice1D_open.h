/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice1D.h"
#include "CellACE110.h"
#include "CellACE30.h"

class Lattice1D_open : public Lattice1D {
 public:
  Lattice1D_open(const char* file, const FactoryCell& factory, const int tipo) : Lattice1D(file, factory), tipo_(tipo) {};
  Lattice1D_open(const std::size_t tamanio, const FactoryCell& factory, const int tipo) : Lattice1D(tamanio, factory), tipo_(tipo) {}
  virtual Cell& operator[](const Position& position) const override;
  protected:
  int tipo_;
};