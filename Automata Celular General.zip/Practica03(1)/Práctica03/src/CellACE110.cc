/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "CellACE110.h"
#include "Lattice1D_periodic.h"
#include "Lattice1D_open.h"

/*
* @brief Método que calcula el siguiente estado de la célula
* @param lattice rejilla de células
* @return void
*/
void CellACE110::NextState(const Lattice& lattice) { 
  State derecha = lattice[PositionDim1<1>(pos_ + 1)].GetState(); 
  State izquierda = lattice[PositionDim1<1>(pos_ - 1)].GetState(); 
  siguiente_estado_ = (estado_ + derecha + (estado_ * derecha) + (izquierda * estado_ * derecha)) % 2;
}