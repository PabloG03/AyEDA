/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "CellACE.h"

class CellACE30 : public CellACE {
 public:
  CellACE30(const Position& position, const State estado) : CellACE(position, estado) {}
  virtual void NextState(const Lattice& lattice) override;
};