/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "FactoryCell.h"

class FactoryCellLife51_346: public FactoryCell {
 public:

  /*
  * @brief Crea una célula Life51_346
  * @param p Posición de la célula
  * @param s Estado de la célula
  * @return Puntero a la célula creada
  */
  virtual Cell* createCell(const Position& position, const State& estado) const override {
  return new CellLife51_346(position, estado);
  } 
};