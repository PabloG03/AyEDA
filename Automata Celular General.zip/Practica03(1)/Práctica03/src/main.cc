/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice2D_NoBorder.h"
#include "Lattice2D_reflective.h"
#include "Lattice1D_periodic.h"
#include "Lattice1D_open.h"
#include "FactoryCellACE30.h"
#include "FactoryCellACE110.h"
#include "FactoryCellLife23_3.h"
#include "FactoryCellLife51_346.h"
#include <fstream>
#include <iostream>

void ussage() { // función que muestra el uso del programa
  std::cout << "Usage: ./main <lattice_type> <cell_type> <rows> <cols> <iterations>" << std::endl;
  std::cout << "lattice_type: 2D_NoBorder, 2D_reflective, 1D_periodic, 1D_open" << std::endl;
  std::cout << "cell_type: ACE30, ACE110, Life23_3, Life51_346" << std::endl;
  std::cout << "rows: number of rows" << std::endl;
  std::cout << "cols: number of columns" << std::endl;
  std::cout << "iterations: number of iterations" << std::endl;
}

int main(int argc, char *argv[]) {
  Lattice* lattice;
  int dim = 0;
  int filas = 0;
  int columnas = 0;
  char* file1;
  bool init = false;
  std::string line;
  std::string CellType;
  std::string Border;

  for (int i = 0; i < argc; i++) { //se comrpueba los parámetros introducidos
    std::string arg = argv[i];
    if (arg == "-h" || arg == "--help") {
      ussage();
      return 0;
    }
    if (arg == "-dim") { //se comprueba la dimensión introducida
      dim = std::stoi(argv[i + 1]);
      if (dim < 1 || dim > 2) {
        std::cout << "Invalid dimension" << std::endl;
        return 1;
      }
    }
    if (arg == "-size") { //se comprueba el tamaño de la lattice introducido
      if (dim == 1) {
        filas = std::stoi(argv[i + 1]);
      } else if (dim == 2) {
        filas = std::stoi(argv[i + 1]);
        columnas = std::stoi(argv[i + 2]);
      } else {
        std::cout << "Invalid dimension" << std::endl;
        return 1;
      }
    }
    if (arg == "-cell") { //se comprueba el tipo de célula introducido
      CellType = argv[i + 1];
      if (CellType != "CellACE30" && CellType != "CellACE110" && CellType != "CellLife23_3" && CellType != "CellLife51_346") {
        std::cout << "Invalid cell type" << std::endl;
        return 1;
      }
    }
    if (arg == "-border") { //se comprueba el tipo de borde introducido
      Border = argv[i + 1];
      if (Border != "noborder" && Border != "reflective" && Border != "periodic" && Border != "open") {
        std::cout << "Invalid border type" << std::endl;
        return 1;
      }
      if (Border == "open") {
        if (atoi(argv[i + 2]) != 0 && atoi(argv[i + 2]) != 1) {
          std::cout << "Invalid open border type" << std::endl;
          return 1;
        }
        if (atoi(argv[i + 2]) == 0) {
          Border = "openf";
        } else {
          Border = "openc";
        }
      }
    }
    if (arg == "-init") { //se comprueba si se ha introducido un archivo de inicialización
      file1 = argv[i + 1];
      std::ifstream archivo(file1);
      getline(archivo, line);
      dim = line[0] - '0';
      init = true;
    }
  }

  if (dim == 1) { //se crea la lattice en función de los parámetros introducidos
    if (Border == "openf" && init == false) {
      if (CellType == "CellACE30") {lattice = new Lattice1D_open(filas, FactoryCellAce30(), 0);}
      if (CellType == "CellACE110") {lattice = new Lattice1D_open(filas, FactoryCellAce110(), 0);}
    } else if (Border == "openf" && init == true){
      if (CellType == "CellACE30") {lattice = new Lattice1D_open(file1, FactoryCellAce30(), 0);}
      if (CellType == "CellACE110") {lattice = new Lattice1D_open(file1, FactoryCellAce110(),0);}
    }
    if (Border == "openc" && init == false) {
      if (CellType == "CellACE30") {lattice = new Lattice1D_open(filas, FactoryCellAce30(), 1);}
      if (CellType == "CellACE110") {lattice = new Lattice1D_open(filas, FactoryCellAce110(), 1);}
    } else if (Border == "openc" && init == true){
      if (CellType == "CellACE30") {lattice = new Lattice1D_open(file1, FactoryCellAce30(), 1);}
      if (CellType == "CellACE110") {lattice = new Lattice1D_open(file1, FactoryCellAce110(), 1);}
    }
    if (Border == "periodic" && init == false) {
      if (CellType == "CellACE30") {lattice = new Lattice1D_periodic(filas, FactoryCellAce30());}
      if (CellType == "CellACE110") {lattice = new Lattice1D_periodic(filas, FactoryCellAce110());}
    } else if (Border == "periodic" && init == true){
      if (CellType == "CellACE30") {lattice = new Lattice1D_periodic(file1, FactoryCellAce30());}
      if (CellType == "CellACE110") {lattice = new Lattice1D_periodic(file1, FactoryCellAce110());}
    }
  } else {
    if (Border == "noborder" && init == false) {
      if (CellType == "CellLife23_3") {lattice = new Lattice2D_NoBorder(filas, columnas, FactoryCellLife23_3());}
      if (CellType == "CellLife51_346") {lattice = new Lattice2D_NoBorder(filas, columnas, FactoryCellLife51_346());}
    } else if (Border == "noborder" && init == true){
      if (CellType == "CellLife23_3") {lattice = new Lattice2D_NoBorder(file1, FactoryCellLife23_3());}
      if (CellType == "CellLife51_346") {lattice = new Lattice2D_NoBorder(file1, FactoryCellLife51_346());}
    }
    if (Border == "reflective" && init == false) {
      if (CellType == "CellLife23_3") {lattice = new Lattice2D_reflective(filas, columnas, FactoryCellLife23_3());}
      if (CellType == "CellLife51_346") {lattice = new Lattice2D_reflective(filas, columnas, FactoryCellLife51_346());}
    } else if (Border == "reflective" && init == true){
      if (CellType == "CellLife23_3") {lattice = new Lattice2D_reflective(file1, FactoryCellLife23_3());}
      if (CellType == "CellLife51_346") {lattice = new Lattice2D_reflective(file1, FactoryCellLife51_346());}
    }
  }

  char opcion;
  bool c = false;
  std::string file;
  std::cout << std::endl;
  lattice->Print();

  std::cout << "---------------------------------------------------------" << std::endl << std::endl;
  while (true) { //bucle que permite al usuario seleccionar las opciones en cada iteración del programa
    std::cout << "Seleccione una opción: " << std::endl;
    std::cout << "c: Los comandos n y L no mostrarán el tablero, sino la población" << std::endl;
    std::cout << "n: Siguiente generación" << std::endl;
    std::cout << "L: 5 siguientes generaciones" << std::endl;
    std::cout << "s: Guardar matriz en un archivo" << std::endl;
    std::cout << "x: Salir" << std::endl;
    std::cout << "Opción: ";
    std::cin >> opcion;
    std::cout << std::endl;
    switch (opcion) {
      case 'c':
        c = !c;
        std::cout << std::endl;
        break;
      case 'x':
        return 0;
      case 'n':
        if (c == false) {
          lattice->nextGeneration();
          lattice->Print();
        } else {
          lattice->nextGeneration();
          std::cout << "La población de la lattice (número de células vivas) es de: " << lattice->Population() << std::endl;
        }
        break;
      case 'L':
        if (c == false) {
          for (int i = 0; i < 5; i++) {
            lattice->nextGeneration();
            lattice->Print();
            std::cout << std::endl;
          }
        } else {
          for (int i = 0; i < 5; i++) {
            lattice->nextGeneration();
            std::cout << "La población de la lattice (número de células vivas) es de: " << lattice->Population() << std::endl;
          }
        }
        break;
      case 's':
        std::cout << "Introduzca el nombre del archivo: ";
        std::cin >> file;
        lattice->SaveLattice(file);
        break;
      default:
        std::cout << "Opción no válida" << std::endl;
        continue;
    }
    std::cout << "---------------------------------------------------------" << std::endl << std::endl;
  }
  return 0;
}