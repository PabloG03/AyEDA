/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "FactoryCell.h"

class FactoryCellAce110: public FactoryCell {
 public:

  /*
  * @brief Crea una célula ACE110
  * @param p Posición de la célula
  * @param s Estado de la célula
  * @return Puntero a la célula creada
  */
  virtual Cell* createCell(const Position& position, const State& estado) const override {
    return new CellACE110(position, estado);
  } 
};