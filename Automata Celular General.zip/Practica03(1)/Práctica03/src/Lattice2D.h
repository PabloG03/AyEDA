/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice.h"
#include <vector>

class Lattice2D : public Lattice {
 public:
  Lattice2D(const char* file, const FactoryCell& factory);
  Lattice2D(const int filas, const int columnas, const FactoryCell& factory);
  virtual Cell& operator[](const Position&) const = 0;
  virtual void nextGeneration() = 0;
  virtual std::size_t Population() const override;
  void SaveLattice(std::string& file) override;
  virtual void Print() override;

 protected:
  std::vector<std::vector<Cell*> > lattice_;
  int filas_;
  int columnas_;
};

