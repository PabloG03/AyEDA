/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice.h"

class Lattice1D : public Lattice {
 public:
  Lattice1D(const char* file, const FactoryCell& factory);
  Lattice1D(const std::size_t tamanio, const FactoryCell& factory);
  virtual Cell& operator[](const Position&) const = 0;
  virtual void nextGeneration() override;
  virtual std::size_t Population() const override;
  virtual void SaveLattice(std::string& file) override;
  virtual void Print() override;

 protected:
  Cell** celulas_;
  std::size_t tamanio_;
};