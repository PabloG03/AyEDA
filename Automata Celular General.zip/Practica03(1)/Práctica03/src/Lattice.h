/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "FactoryCell.h"
#include <fstream>

class Cell;

class Lattice {
 public:
  Lattice() {};
  virtual ~Lattice() {};
  Lattice(const char*, FactoryCell&) {};
  virtual Cell& operator[](const Position&) const = 0;
  virtual void nextGeneration() = 0;
  virtual std::size_t Population() const = 0;
  virtual void SaveLattice(std::string& file) = 0;
  virtual void Print() = 0;
 protected:
};