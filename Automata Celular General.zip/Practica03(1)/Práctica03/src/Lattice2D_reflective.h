/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice2D.h"

class Lattice2D_reflective : public Lattice2D {
 public:
  Lattice2D_reflective(const char* file, const FactoryCell& factory) : Lattice2D(file, factory) {}
  Lattice2D_reflective(const int filas, const int columnas, const FactoryCell& factory) : Lattice2D(filas, columnas, factory) {}
  virtual void nextGeneration() override;
  virtual Cell& operator[](const Position& position) const override;
};