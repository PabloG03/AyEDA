/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice1D.h"
#include "CellACE110.h"
#include "CellACE30.h"

class Lattice1D_periodic : public Lattice1D {
 public:
  Lattice1D_periodic(const char* file, const FactoryCell& factory) : Lattice1D(file, factory) {};
  Lattice1D_periodic(const std::size_t tamanio, const FactoryCell& factory) : Lattice1D(tamanio, factory) {};
  virtual Cell& operator[](const Position& position) const override;
};