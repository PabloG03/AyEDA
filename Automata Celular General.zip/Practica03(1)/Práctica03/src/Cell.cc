/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Cell.h"
#include "Lattice.h"

Cell::Cell(const Position& position, const State estado) {
  *position_ = position;
  estado_ = estado;
  siguiente_estado_ = 0;
}

void Cell::SetPosition(const int i) {
  pos_ = i;
}

void Cell::SetColumna(const int j) {
  col_ = j;
}

State Cell::GetState() const {
  return estado_;
}

State Cell::SetState(const State estado) {
  estado_ = estado;
  return estado_;
}

State Cell::GetNextState() const {
  return siguiente_estado_;
}

/*
* @brief Método virtual puro que se encarga de poner el estado de la célula en el siguiente estado
* @param void
* @return void
*/
void Cell::UpdateState() {
  estado_ = siguiente_estado_;
}

std::ostream& Cell::operator<<(std::ostream& os) {
  if (estado_ == 1) {
    os << "X";
  } else {
    os << "[ ]";
  }
}