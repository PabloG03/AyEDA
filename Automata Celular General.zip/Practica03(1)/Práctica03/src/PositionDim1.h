/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Position.h"

template <int Dim=1>
class PositionDim1 : public Position {
 public:
  PositionDim1(int sz, ...) {
    va_list vl;
    va_start(vl, sz);
    Coordinates[0] = sz;
    for (int d = 1; d < Dim; d++) {
      Coordinates[d] = va_arg(vl, int);
    }
    va_end(vl);
  }
  virtual Coor_t operator[](const unsigned int sz) const override {
    return Coordinates[sz];
  }

 private:
  Coor_t Coordinates[Dim];
};