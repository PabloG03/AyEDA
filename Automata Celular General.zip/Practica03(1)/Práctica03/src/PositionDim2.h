/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Position.h"

template <int Dim=2>
class PositionDim2 : public Position {
 public:
  PositionDim2(int filas, int columnas, ...) {
    va_list vl;
    va_start(vl, columnas);
    Coordinates[0] = filas;
    Coordinates[1] = columnas;
    for (int d = 2; d < Dim; d++) {
      Coordinates[d] = va_arg(vl, int);
    }
    va_end(vl);
  }
  virtual Coor_t operator[](const unsigned int filas) const override {
    return Coordinates[filas];
  }

 private:
  Coor_t Coordinates[Dim];
};