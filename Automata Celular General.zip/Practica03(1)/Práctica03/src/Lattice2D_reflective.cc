/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice2D_reflective.h"

Cell& Lattice2D_reflective::operator[](const Position& position) const {
  Coor_t positionX = position[0];
  Coor_t positionY = position[1];
  while (positionX < 0 || positionX >= filas_ || positionY < 0 || positionY >= columnas_) {
    if (positionX < 0) {positionX = + 1;}
    if (positionY < 0) {positionY = + 1;}
    if (positionX >= filas_) {positionX -= 1 ;}
    if (positionY >= columnas_) {positionY -= 1 ;}
  }
  return *lattice_[positionX][positionY];
}

/*
* @brief Método que avanza una generación en el autómata celular
* @param void
* @return void
*/
void Lattice2D_reflective::nextGeneration() {
  for (int i = 0; i < filas_; ++i) {
    for (int j = 0; j < columnas_; ++j) {
      lattice_[i][j]->NextState(*this);
    }
  }
  for (int i = 0; i < filas_; ++i) {
    for (int j = 0; j < columnas_; ++j) {
      lattice_[i][j]->UpdateState();
    }
  }
}