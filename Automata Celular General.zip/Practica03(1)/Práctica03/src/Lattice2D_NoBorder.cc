/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice2D_NoBorder.h"

Cell& Lattice2D_NoBorder::operator[](const Position& position) const{
  Coor_t positionX = position[0];
  Coor_t positionY = position[1];
  if (positionX < 0 || positionX >= filas_ || positionY < 0 || positionY >= columnas_) {
    Cell *cell = new CellLife23_3(PositionDim2<2>(0, 0), 0);
    return *cell;
  }
  return *lattice_[positionX][positionY];
}

/*
* @brief calcula la siguiente generación de células
* @param void
* @return void
*/
void Lattice2D_NoBorder::nextGeneration() {
  for (int i = 0; i < filas_; ++i) {
    for (int j = 0; j < columnas_; ++j) {
      lattice_[i][j]->NextState(*this);
    }
  }
  if (ComprobarCeldas() == true) {
    Anadir();
    CorregirPosiciones();
  }
  for (int i = 0; i < filas_; ++i) {
    for (int j = 0; j < columnas_; ++j) {
      lattice_[i][j]->UpdateState();
    }
  }
}

/*
* @brief calcula la población de células vivas
* @param void
* @return std::size_t células vivas
*/
bool Lattice2D_NoBorder::ComprobarCeldas() {
  filainit = false;
  filafin = false;
  columnainit = false;
  columnafin = false;
  bool retorno = false;
  for (int i = 0; i < filas_; i++) {
    if (lattice_[i][0]->GetState() == 1) {
      columnainit = true;
      retorno = true;
      if (lattice_[i][0]->GetNextState() == 1) {
        columnainit2 = true;
      }
    }
    if (lattice_[i][columnas_ - 1]->GetState() == 1) {
      columnafin = true;
      retorno = true;
      if (lattice_[i][columnas_ - 1]->GetNextState() == 1) {
        columnafin2 = true;
      }
    }
  }
  for (int i = 0; i < columnas_; i++) {
    if (lattice_[0][i]->GetState() == 1) {
      filainit = true;
      retorno = true;
      if (lattice_[0][i]->GetNextState() == 1) {
        filainit2 = true;
      }
    }
    if (lattice_[filas_ - 1][i]->GetState() == 1) {
      filafin = true;
      retorno = true;
      if (lattice_[filas_ -1][0]->GetNextState() == 1) {
        filafin2 = true;
      }
    }
  }
  return retorno;
}

/*
* @brief añade celdas si es necesario
* @param void
* @return void
*/
void Lattice2D_NoBorder::Anadir() {
  if (columnafin2 == true) {
    for (int j = 0; j < 2; j++) {
    AnadirColumnaFinal();
    columnas_++;
    }
  }
  if (columnafin == true) {
    AnadirColumnaFinal();
    columnas_++;
  }
  if (columnainit == true) {
    AnadirColumnaInicio();
    columnas_++;
  }
  if (columnainit2 == true) {
    for (int j = 0; j < 2; j++) {
    AnadirColumnaInicio();
    columnas_++;
    }
  }
  if (filainit2 == true) {
    for (int j = 0; j < 2; j++) {
    AnadirFilaInicio();
    filas_++;
    }
  }
  if (filainit == true) {
    AnadirFilaInicio();
    filas_++;
  }
  if (filafin2 == true) {
    for (int j = 0; j < 2; j++) {
    AnadirFilaFinal();
    filas_++;
    }
  }
  if (filafin == true) {
    AnadirFilaFinal();
    filas_++;
  }
}

/*
* @brief añade una columna al inicio de la matriz
* @param void
* @return void
*/
void Lattice2D_NoBorder::AnadirColumnaInicio() {
    for (int i = 0; i < filas_; i++) {
    lattice_[i].insert(lattice_[i].begin(), new CellLife23_3(PositionDim2<2>(i, 0), 0));
  }
}

/*
* @brief añade una columna al final de la matriz
* @param void
* @return void
*/
void Lattice2D_NoBorder::AnadirColumnaFinal() {
  for (int i = 0; i < filas_; i++) {
    lattice_[i].push_back(new CellLife23_3(PositionDim2<2>(i, 0), 0));
  }
}

/*
* @brief añade una fila al inicio de la matriz
* @param void
* @return void
*/
void Lattice2D_NoBorder::AnadirFilaInicio() {
  lattice_.insert(lattice_.begin(), std::vector<Cell*>(columnas_));
  for (int i = 0; i < columnas_; i++) {
    lattice_[0][i] = new CellLife23_3(PositionDim2<2>(0, i), 0);
  }
}

/*
* @brief añade una fila al final de la matriz
* @param void
* @return void
*/
void Lattice2D_NoBorder::AnadirFilaFinal() {
  lattice_.push_back(std::vector<Cell*>(columnas_));
  for (int i = 0; i < columnas_ ; i++) {
    lattice_[filas_][i] = new CellLife23_3(PositionDim2<2>(filas_, i), 0);
  }
}

/*
* @brief corrige las posiciones de las celdas
* @param void
* @return void
*/
void Lattice2D_NoBorder::CorregirPosiciones() {
  for (int i = 0; i < filas_; i++) {
    for (int j = 0; j < columnas_; j++) {
      lattice_[i][j]->SetPosition(i);
      lattice_[i][j]->SetColumna(j);
    }
  }
}
