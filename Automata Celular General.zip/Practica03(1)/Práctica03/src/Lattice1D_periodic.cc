/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice1D_periodic.h"

Cell& Lattice1D_periodic::operator[](const Position& position) const {
  int positionX = position[0];
  while (positionX < 0 || positionX >= tamanio_) {
    if (positionX < 0) {
      positionX += tamanio_;
    } else {
      positionX -= tamanio_;
    }
  }
  return *celulas_[positionX];
}