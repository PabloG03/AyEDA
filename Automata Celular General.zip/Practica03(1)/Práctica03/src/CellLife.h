/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Cell.h"
#include "PositionDim2.h"

class CellLife : public Cell {
 public:
  CellLife(const Position& position, const State estado) : Cell(position, estado) {};
  virtual void NextState(const Lattice& lattice) = 0;
  protected:
  int Coors[8][2] = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};
};
