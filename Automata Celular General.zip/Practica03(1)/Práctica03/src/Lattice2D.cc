/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice2D.h"

Lattice2D::Lattice2D(const int filas, const int columnas, const FactoryCell& factory) {
  filas_ = filas; 
  columnas_ = columnas;
  for (int i = 0; i < filas_; i++) {
    lattice_.push_back(std::vector<Cell*>());
    for (int j = 0; j < columnas_; j++) {
      lattice_[i].push_back(factory.createCell((PositionDim2<2>(i, j)), 0));
      lattice_[i][j]->SetPosition(i);
      lattice_[i][j]->SetColumna(j);
    }
  }
}

Lattice2D::Lattice2D(const char* file, const FactoryCell& factory) {
  std::string line;
  std::ifstream archivo(file);
  getline(archivo, line); getline(archivo, line);
  filas_ = line[0] - '0';
  getline(archivo, line);
  columnas_ = line[0] - '0';
  for (int i = 0; i < filas_; i++) {
    getline(archivo, line);
    lattice_.push_back(std::vector<Cell*>());
    for (int j = 0; j < columnas_; j++) {
      lattice_[i].push_back(factory.createCell((PositionDim2<2>(i, j)), line[j] - '0'));
      lattice_[i][j]->SetPosition(i);
      lattice_[i][j]->SetColumna(j);
    }
  }
  archivo.close();
}

/*
* @brief calcula cuantas células vivas hay
* @param void
* @return std::size_t número de células vivas
*/
std::size_t Lattice2D::Population() const {
  std::size_t population = 0;
  for (std::size_t i = 0; i < filas_; ++i) {
    for (std::size_t j = 0; j < columnas_; ++j) {
      if (lattice_[i][j]->GetState() == 1) {
        ++population;
      }
    }
  }
  return population;
}

/*
* @brief guarda el estado de la malla en un archivo
* @param std::string& nombre del archivo
* @return void
*/
void Lattice2D::SaveLattice(std::string& file) {
  std::ofstream archivo(file);
  for (std::size_t i = 0; i < filas_; ++i) {
    for (std::size_t j = 0; j < columnas_; ++j) {
    archivo << lattice_[i][j]->GetState() << " ";
    }
    archivo << std::endl;
  }
  archivo.close();
}

/*
* @brief imprime el estado de la malla
* @param void
* @return void
*/
void Lattice2D::Print() {
  for (std::size_t i = 0; i < filas_; ++i) {
    std::cout << '|';
    for (std::size_t j = 0; j < columnas_; ++j) {
      if (lattice_[i][j]->GetState() == 1) {
        std::cout << 'X';
      } else {
        std::cout << ' ';
      }
      std::cout << '|';
    }
    std::cout << std::endl;
  }
  std::cout << std::endl;
}