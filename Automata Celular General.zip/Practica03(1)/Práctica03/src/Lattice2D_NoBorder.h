/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include "Lattice2D.h"

class Lattice2D_NoBorder : public Lattice2D {
 public:
  Lattice2D_NoBorder(const char* file, const FactoryCell& factory) : Lattice2D(file, factory) {}
  Lattice2D_NoBorder(const int filas, const int columnas, const FactoryCell& factory) : Lattice2D(filas, columnas, factory) {}
  virtual Cell& operator[](const Position& position) const override;
  virtual void nextGeneration() override;

  
  protected:
  bool ComprobarCeldas();
  void Anadir();
  void AnadirFilaInicio();
  void AnadirFilaFinal();
  void AnadirColumnaInicio();
  void AnadirColumnaFinal();
  void CorregirPosiciones();
  bool filainit, filafin, columnainit, columnafin;
  bool filainit2, filafin2, columnainit2, columnafin2;
};
