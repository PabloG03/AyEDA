/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#pragma once
#include <iostream>
#include "Position.h"

typedef int State;

class Lattice;

class Cell {
 public:
  Cell(const Position& position, const State estado);
  void SetPosition(const int i);
  void SetColumna(const int j);
  State GetState() const;
  State SetState(const State estado);
  State GetNextState() const;
  virtual void NextState(const Lattice& lattice) = 0;
  void UpdateState();
  virtual std::ostream& operator<<(std::ostream& os);
 protected:
  Position* position_;
  State estado_;
  State siguiente_estado_;
  int pos_; // como no funcionaba el position_ he creado dos variables para guardar la posicion con int
  int col_; // solo cojo pos_ si es unidiaimensional y col_ si es bidimensional
};