/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice1D.h"

Lattice1D::Lattice1D(const std::size_t tamanio, const FactoryCell& factory) {
  tamanio_ = tamanio;
  celulas_ = new Cell*[tamanio];
  for (std::size_t i = 0; i < tamanio_; i++) {
    Position* position = new PositionDim1<1>(i);
    celulas_[i] = factory.createCell(*position, 0);
    celulas_[i]->SetPosition(i);
  }
}

Lattice1D::Lattice1D(const char* file, const FactoryCell& factory) {
  std::string line;
  std::ifstream archivo(file);
  getline(archivo, line); 
  getline(archivo, line);
  tamanio_ = line[0] - '0';
  celulas_ = new Cell*[tamanio_];
  getline(archivo, line);
  for (std::size_t i = 0; i < tamanio_; i++) {
    Position* position = new PositionDim1<1>(i);
    celulas_[i] = factory.createCell(*position, line[i] - '0');
    celulas_[i]->SetPosition(i);
  }
  archivo.close();
}

/*
* @brief calcula la siguiente generación de células
* @param void
* @return void
*/
void Lattice1D::nextGeneration() {
  for (std::size_t i = 0; i < tamanio_; ++i) {
    celulas_[i]->NextState(*this);
  }
  for (std::size_t i = 0; i < tamanio_; ++i) {
    celulas_[i]->UpdateState();
  }
}

/*
* @brief calcula la población de células vivas
* @param void
* @return std::size_t células vivas
*/
std::size_t Lattice1D::Population() const {
  std::size_t population = 0;
  for (std::size_t i = 0; i < tamanio_; ++i) {
    if (celulas_[i]->GetState() == 1) {
      ++population;
    }
  }
  return population;
}

/*
* @brief guarda la lattice en un archivo
* @param std::string& nombre del archivo
* @return void
*/
void Lattice1D::SaveLattice(std::string& file) {
  std::ofstream archivo(file);
  for (std::size_t i = 0; i < tamanio_; ++i) {
    archivo << celulas_[i]->GetState() << " ";
  }
  archivo.close();
}

/*
* @brief imprime la lattice
* @param void
* @return void
*/
void Lattice1D::Print() {
    std::cout << '|';
    for (std::size_t i = 0; i < tamanio_; i++) {
      if (celulas_[i]->GetState() == 1) {
        std::cout << 'X';
      } else {
        std::cout << ' ';
      }
      std::cout << '|';
    }
  std::cout << std::endl;
}