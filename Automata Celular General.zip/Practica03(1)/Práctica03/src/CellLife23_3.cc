/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "CellLife23_3.h"
#include "Lattice2D_NoBorder.h"
#include "Lattice2D_reflective.h"

/*
* @brief Método que calcula el siguiente estado de la célula
* @param lattice rejilla de células
* @return void
*/
void CellLife23_3::NextState(const Lattice& lattice) {
  int count = 0;
  for (int i = 0; i < 8; i++) {
    State vecino = lattice[PositionDim2<2>(pos_ + Coors[i][0], col_ + Coors[i][1])].GetState();
    count += vecino;
  }
  if (estado_ == 1) {
    if (count < 2 || count > 3) {
      siguiente_estado_ = 0;
    } else {
      siguiente_estado_ = 1;
    }
  } else {
    if (count == 3) {
      siguiente_estado_ = 1;
    } else {
      siguiente_estado_ = 0;
    }
  }
}