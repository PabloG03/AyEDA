/* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Asignatura: Algoritmos y Estructuras de Datos Avanzadas
* Curso: 2º
* Práctica 3
* Autor: Pablo García Pérez
* Correo: alu0101496139@ull.edu.es
* Fecha: 07/03/2024
* source Autómata celular general
*/

#include "Lattice1D_open.h"

Cell& Lattice1D_open::operator[](const Position& position) const {
  if ((position[0] < 0 || position[0] >= tamanio_) && tipo_ == 0) {
    Cell *cell = new CellACE30(PositionDim1<1>(0), 0);
    return *cell;
  }
  if ((position[0] < 0 || position[0] >= tamanio_) && tipo_ == 1) {
    Cell *cell = new CellACE30(PositionDim1<1>(0), 1);
    return *cell;
  }
  return *celulas_[position[0]];
}